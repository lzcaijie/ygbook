<?php
return array(
	'DB_TYPE'	=>  'mysql',
	'DB_HOST'	=>  'localhost',
	'DB_NAME'	=>  'books_cdmytravel',
	'DB_USER'	=>  'books_cdmytravel',
	'DB_PWD'	=>  'WhN7WsajfMG2k7J7',
	'DB_PORT'	=>  '3306',
	'DB_PREFIX'	=>  'book_'
);