<?php
return array(
	'LOAD_EXT_CONFIG' => 'database,rewrite',
	'VER' => '6.14',
	'URL_MODULE_MAP' => array('caijie' => 'admin'),
);
